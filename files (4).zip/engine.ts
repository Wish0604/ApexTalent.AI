// lib/ai-evaluation/engine.ts
//
// The single AI Evaluation Engine every module (repo, interview, resume,
// coding task, pitch deck) routes through. This replaces random.uniform()
// stubs with a real Claude API call, a strict rubric, and a validated
// JSON schema so scores are explainable and reproducible in shape.

import Anthropic from "@anthropic-ai/sdk";
import { Rubric, SubmissionContext, EvaluationResult, CriterionResult, HiringRecommendation } from "./types";

const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY,
});

// Swap for claude-haiku-4-5-20251001 for cheap/high-volume screening passes,
// or claude-opus-4-8 for final-round / high-stakes evaluations.
const EVAL_MODEL = "claude-sonnet-5";

function buildSystemPrompt(rubric: Rubric): string {
  const criteriaBlock = rubric.criteria
    .map(
      (c) =>
        `- "${c.key}" (${c.label}), weight ${c.weight}%: ${c.description}`
    )
    .join("\n");

  return `You are a senior technical evaluator for ApexTalent, an AI recruitment platform.

${rubric.context}

Score the candidate's submission strictly against this rubric. Weights must be treated as given — do not renormalize them:
${criteriaBlock}

Rules:
- Score each criterion independently on a 0-100 scale based ONLY on evidence in the submission provided. If information for a criterion is missing, score it low and say so in the evidence field — do not assume competence that isn't shown.
- "evidence" must reference specific, concrete details from the submission (function names, commit messages, specific claims), paraphrased in your own words — not invented.
- Be strict. Most real submissions should NOT score above 90 unless genuinely excellent. Avoid score clustering around 80-90; use the full range.
- hiringRecommendation must be one of: "strong_hire", "hire", "lean_hire", "no_hire", "strong_no_hire".
- Respond with ONLY valid JSON matching this exact shape, no markdown fences, no preamble:

{
  "criteria": [
    { "key": "<criterion_key>", "score": <0-100 integer>, "evidence": "<specific evidence, 1-2 sentences>" }
  ],
  "strengths": ["<short bullet>", "..."],
  "weaknesses": ["<short bullet>", "..."],
  "suggestedImprovements": ["<short bullet>", "..."],
  "hiringRecommendation": "<one of the 5 values above>",
  "summary": "<2-3 sentence overall summary>"
}

Include exactly one entry in "criteria" for every criterion key listed above, using the exact keys given.`;
}

interface RawModelJson {
  criteria: { key: string; score: number; evidence: string }[];
  strengths: string[];
  weaknesses: string[];
  suggestedImprovements: string[];
  hiringRecommendation: HiringRecommendation;
  summary: string;
}

function extractJson(text: string): RawModelJson {
  // Defensive: strip markdown fences if the model adds them anyway
  const cleaned = text.replace(/```json|```/g, "").trim();
  try {
    return JSON.parse(cleaned) as RawModelJson;
  } catch (err) {
    throw new Error(
      `AI Evaluation Engine: failed to parse model output as JSON. Raw output: ${cleaned.slice(0, 500)}`
    );
  }
}

/**
 * Runs a full rubric-based evaluation against a candidate submission using
 * the real Claude API. This is the ONLY function that should ever produce
 * an EvaluationResult — every evaluator module (repo, interview, resume,
 * coding task) calls this with a different rubric + submission context.
 */
export async function runRubricEvaluation(
  rubric: Rubric,
  submission: SubmissionContext
): Promise<EvaluationResult> {
  const systemPrompt = buildSystemPrompt(rubric);

  const userContent = `Task/Role: ${submission.taskTitle}
${submission.candidateName ? `Candidate: ${submission.candidateName}\n` : ""}
--- SUBMISSION CONTENT START ---
${submission.content}
--- SUBMISSION CONTENT END ---
${submission.metadata ? `\nAdditional metadata:\n${JSON.stringify(submission.metadata, null, 2)}` : ""}`;

  const response = await anthropic.messages.create({
    model: EVAL_MODEL,
    max_tokens: 2000,
    system: systemPrompt,
    messages: [{ role: "user", content: userContent }],
  });

  const textBlock = response.content.find((block) => block.type === "text");
  if (!textBlock || textBlock.type !== "text") {
    throw new Error("AI Evaluation Engine: model returned no text content.");
  }

  const parsed = extractJson(textBlock.text);

  // Validate every rubric criterion was scored, then compute weighted scores
  // ourselves — never trust the model to do the arithmetic.
  const criteriaResults: CriterionResult[] = rubric.criteria.map((rc) => {
    const match = parsed.criteria.find((p) => p.key === rc.key);
    if (!match) {
      throw new Error(
        `AI Evaluation Engine: model omitted required criterion "${rc.key}" for rubric "${rubric.id}".`
      );
    }
    const score = Math.max(0, Math.min(100, Math.round(match.score)));
    return {
      key: rc.key,
      label: rc.label,
      weight: rc.weight,
      score,
      weightedScore: Math.round(score * (rc.weight / 100) * 100) / 100,
      evidence: match.evidence,
    };
  });

  const overallScore = Math.round(
    criteriaResults.reduce((sum, c) => sum + c.weightedScore, 0)
  );

  return {
    rubricId: rubric.id,
    candidateId: submission.candidateId,
    overallScore,
    criteria: criteriaResults,
    strengths: parsed.strengths ?? [],
    weaknesses: parsed.weaknesses ?? [],
    suggestedImprovements: parsed.suggestedImprovements ?? [],
    hiringRecommendation: parsed.hiringRecommendation,
    summary: parsed.summary,
    modelUsed: EVAL_MODEL,
    evaluatedAt: new Date().toISOString(),
  };
}
