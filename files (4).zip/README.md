# ApexTalent — AI Evaluation Engine

Real replacement for the `random.uniform()` stub agents. One rubric-driven
engine, powered by the actual Claude API, used by every evaluation surface.

## What changed from your draft

| Old (stub) | New (real) |
|---|---|
| `evaluate_repository_agent()` used `random.uniform(84, 97.5)` | `evaluateRepository()` fetches real README/commits/PRs/source files via GitHub REST API, sends them to Claude with the rubric, parses real scores |
| `evaluate_ppt_deck_agent()` used random scores | Routes through `runRubricEvaluation(PITCH_DECK_RUBRIC, ...)` with actual extracted slide text |
| `calculate_team_contributions_agent()` used `random.randint` | `computeTeamContributions()` pulls `/stats/contributors` and `/pulls` from GitHub — real commits, real additions/deletions, real PR counts |
| Arbitrary "Final Score: 84/100" with no traceability | `overallScore` is computed in code from Claude's per-criterion scores × rubric weights — never invented by the model |

## Files

```
lib/ai-evaluation/
  types.ts                 - shared types (Rubric, EvaluationResult, etc.)
  rubrics.ts                - all rubric definitions (weights match your spec)
  engine.ts                  - THE core engine: calls Claude API, validates + scores
  github-evaluator.ts        - real GitHub data fetch + repo evaluation
  team-contributions.ts      - real contributor stats from GitHub API

app/api/evaluate/
  repository/route.ts        - POST endpoint for GitHub repo evaluation
  general/route.ts           - POST endpoint for coding/interview/resume/pitch-deck
```

## Setup

```bash
npm install @anthropic-ai/sdk
```

Env vars (`.env.local`):
```
ANTHROPIC_API_KEY=sk-ant-...
GITHUB_TOKEN=ghp_...     # needs public_repo scope for public repos
```

## Usage examples

**Evaluate a candidate's GitHub project:**
```ts
import { evaluateRepository } from "@/lib/ai-evaluation/github-evaluator";

const result = await evaluateRepository(
  "https://github.com/someuser/their-project",
  candidateId,
  candidateName
);
// result.overallScore, result.criteria[], result.hiringRecommendation, etc.
```

**Evaluate a resume for Talent Score:**
```ts
import { runRubricEvaluation } from "@/lib/ai-evaluation/engine";
import { RESUME_RUBRIC } from "@/lib/ai-evaluation/rubrics";

const result = await runRubricEvaluation(RESUME_RUBRIC, {
  candidateId,
  taskTitle: "Backend AI Engineer — Talent Score",
  content: resumeText, // extracted resume text
});
```

**Real team contribution split (no more random.randint):**
```ts
import { computeTeamContributions } from "@/lib/ai-evaluation/team-contributions";

const splits = await computeTeamContributions("org-or-user", "repo-name", [
  { id: "c1", full_name: "Vishva", github_username: "vishva-gh" },
  { id: "c2", full_name: "Teammate", github_username: "teammate-gh" },
]);
```

## Notes for your Talent Score pipeline

- `EVAL_MODEL` in `engine.ts` is set to `claude-sonnet-5`. For high-volume
  screening (e.g. scoring hundreds of resumes), swap to `claude-haiku-4-5-20251001`
  for lower cost/latency; for final-round or dispute cases, swap to `claude-opus-4-8`.
- `engine.ts` throws if the model omits a rubric criterion or returns unparseable
  JSON — surface that as a retry in your API route rather than silently failing,
  since a bad score with no explanation is worse than a visible error.
- The `overallScore` math (weighted sum of criteria) happens in your code, not
  inside the model's output — this is what makes the score auditable/explainable
  instead of an arbitrary "84/100" the model just declared.
- All GitHub-derived text sent to Claude is truncated (README to 6k chars, each
  sampled file to 2k chars) to keep token usage predictable across large repos.
