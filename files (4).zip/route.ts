// app/api/evaluate/repository/route.ts
//
// POST /api/evaluate/repository
// Body: { githubUrl: string, candidateId?: string, candidateName?: string }
//
// Wires the real AI Evaluation Engine (Claude API + real GitHub data) into
// a Next.js route your dashboard/talent-scoring pipeline can call directly.

import { NextRequest, NextResponse } from "next/server";
import { evaluateRepository } from "@/lib/ai-evaluation/github-evaluator";

export async function POST(req: NextRequest) {
  try {
    const { githubUrl, candidateId, candidateName } = await req.json();

    if (!githubUrl) {
      return NextResponse.json({ error: "githubUrl is required" }, { status: 400 });
    }

    const result = await evaluateRepository(githubUrl, candidateId, candidateName);

    // TODO: persist `result` to Supabase, e.g.:
    // await supabase.from("evaluations").insert({ candidate_id: candidateId, ...result });

    return NextResponse.json(result);
  } catch (err: any) {
    console.error("Repository evaluation failed:", err);
    return NextResponse.json({ error: err.message ?? "Evaluation failed" }, { status: 500 });
  }
}
