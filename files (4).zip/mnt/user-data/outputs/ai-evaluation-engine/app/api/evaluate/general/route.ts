// app/api/evaluate/general/route.ts
//
// POST /api/evaluate/general
// Body: {
//   rubricId: "coding_task_v1" | "interview_v1" | "resume_v1" | "pitch_deck_v1" | "api_design_v1",
//   candidateId?: string,
//   candidateName?: string,
//   taskTitle: string,
//   content: string   // the actual code / transcript / resume text / slide text
// }
//
// One endpoint handles every non-GitHub evaluation type since they all
// share the same rubric-driven engine — only the rubric + content differ.

import { NextRequest, NextResponse } from "next/server";
import { runRubricEvaluation } from "@/lib/ai-evaluation/engine";
import { ALL_RUBRICS } from "@/lib/ai-evaluation/rubrics";

export async function POST(req: NextRequest) {
  try {
    const { rubricId, candidateId, candidateName, taskTitle, content, metadata } = await req.json();

    const rubric = ALL_RUBRICS[rubricId];
    if (!rubric) {
      return NextResponse.json(
        { error: `Unknown rubricId "${rubricId}". Valid options: ${Object.keys(ALL_RUBRICS).join(", ")}` },
        { status: 400 }
      );
    }
    if (!content || !taskTitle) {
      return NextResponse.json({ error: "taskTitle and content are required" }, { status: 400 });
    }

    const result = await runRubricEvaluation(rubric, {
      candidateId,
      candidateName,
      taskTitle,
      content,
      metadata,
    });

    return NextResponse.json(result);
  } catch (err: any) {
    console.error("Evaluation failed:", err);
    return NextResponse.json({ error: err.message ?? "Evaluation failed" }, { status: 500 });
  }
}
