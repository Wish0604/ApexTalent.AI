// lib/ai-evaluation/team-contributions.ts
//
// Replaces calculate_team_contributions_agent()'s random.randint stubs with
// real numbers pulled from GitHub's contributor stats API: actual commits,
// actual additions/deletions per author, actual PR counts.

export interface TeamMemberInput {
  id: string;
  full_name: string;
  /** GitHub username — required to match against contributor stats */
  github_username: string;
}

export interface TeamContributionResult {
  candidate_id: string;
  full_name: string;
  contribution_percentage: number;
  commits_count: number;
  additions: number;
  deletions: number;
  prs_count: number;
  leadership_index: number; // 0-99, derived from commit share + merged PR share
  ownership_role: "Lead Contributor" | "Core Contributor" | "Contributor";
}

const GITHUB_API = "https://api.github.com";

function githubHeaders() {
  return {
    Accept: "application/vnd.github+json",
    Authorization: `Bearer ${process.env.GITHUB_TOKEN}`,
    "X-GitHub-Api-Version": "2022-11-28",
  };
}

async function ghGet(path: string, retries = 3): Promise<any> {
  const res = await fetch(`${GITHUB_API}${path}`, { headers: githubHeaders() });
  // GitHub computes contributor stats asynchronously — 202 means "come back shortly"
  if (res.status === 202 && retries > 0) {
    await new Promise((r) => setTimeout(r, 1500));
    return ghGet(path, retries - 1);
  }
  if (!res.ok) throw new Error(`GitHub API error ${res.status} on ${path}`);
  return res.json();
}

export async function computeTeamContributions(
  owner: string,
  repo: string,
  teamMembers: TeamMemberInput[]
): Promise<TeamContributionResult[]> {
  if (teamMembers.length === 0) return [];

  const [contributorStats, pulls] = await Promise.all([
    ghGet(`/repos/${owner}/${repo}/stats/contributors`),
    ghGet(`/repos/${owner}/${repo}/pulls?state=all&per_page=100`),
  ]);

  const statsByLogin = new Map<string, { commits: number; additions: number; deletions: number }>();
  for (const entry of contributorStats ?? []) {
    const login = entry.author?.login;
    if (!login) continue;
    const additions = entry.weeks.reduce((s: number, w: any) => s + w.a, 0);
    const deletions = entry.weeks.reduce((s: number, w: any) => s + w.d, 0);
    statsByLogin.set(login, { commits: entry.total, additions, deletions });
  }

  const prCountByLogin = new Map<string, number>();
  for (const pr of pulls ?? []) {
    const login = pr.user?.login;
    if (!login) continue;
    prCountByLogin.set(login, (prCountByLogin.get(login) ?? 0) + 1);
  }

  const raw = teamMembers.map((member) => {
    const stats = statsByLogin.get(member.github_username) ?? { commits: 0, additions: 0, deletions: 0 };
    const prs = prCountByLogin.get(member.github_username) ?? 0;
    // Weighted "effort" score: commits matter, but so does churn volume
    const effort = stats.commits * 3 + Math.min(stats.additions + stats.deletions, 5000) / 50;
    return { member, stats, prs, effort };
  });

  const totalEffort = raw.reduce((s, r) => s + r.effort, 0) || 1;

  const results: TeamContributionResult[] = raw
    .map((r) => {
      const share = Math.round((r.effort / totalEffort) * 1000) / 10; // 1 decimal
      const prShare = raw.reduce((s, x) => s + x.prs, 0) > 0
        ? r.prs / raw.reduce((s, x) => s + x.prs, 0)
        : 0;
      const leadershipIndex = Math.round(Math.min(99, share * 1.5 + prShare * 40));

      let ownershipRole: TeamContributionResult["ownership_role"] = "Contributor";
      if (share >= 40) ownershipRole = "Lead Contributor";
      else if (share >= 20) ownershipRole = "Core Contributor";

      return {
        candidate_id: r.member.id,
        full_name: r.member.full_name,
        contribution_percentage: share,
        commits_count: r.stats.commits,
        additions: r.stats.additions,
        deletions: r.stats.deletions,
        prs_count: r.prs,
        leadership_index: leadershipIndex,
        ownership_role: ownershipRole,
      };
    })
    .sort((a, b) => b.contribution_percentage - a.contribution_percentage);

  return results;
}
