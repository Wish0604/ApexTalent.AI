# backend/app/services/rag/vector_store.py
#
# Thin wrapper around a single Supabase `rag_documents` table (pgvector) that
# holds every embedded artifact the Copilot can retrieve: resumes, GitHub
# analyses, interview transcripts, recruiter notes, job descriptions, and
# company policy docs. One table + a `doc_type` column keeps this simple
# enough to ship for a hackathon while staying real (not mocked).

from typing import List, Optional, Literal

from .embeddings import embed_texts, embed_query, chunk_text
from ..db import supabase

DocType = Literal[
    "resume", "github_analysis", "interview_transcript", "recruiter_note",
    "job_description", "assessment_report", "company_policy", "email_template",
]


async def upsert_document(
    *,
    source_id: str,           # candidate_id, job_id, or policy doc id
    doc_type: DocType,
    text: str,
    metadata: Optional[dict] = None,
) -> int:
    """Chunk, embed, and store a document. Returns number of chunks stored."""
    chunks = chunk_text(text)
    vectors = await embed_texts(chunks, input_type="document")

    rows = [
        {
            "source_id": source_id,
            "doc_type": doc_type,
            "chunk_index": i,
            "content": chunk,
            "embedding": vector,
            "metadata": metadata or {},
        }
        for i, (chunk, vector) in enumerate(zip(chunks, vectors))
    ]

    # Replace any existing chunks for this source_id + doc_type (re-ingestion)
    supabase.table("rag_documents").delete().eq("source_id", source_id).eq("doc_type", doc_type).execute()
    supabase.table("rag_documents").insert(rows).execute()
    return len(rows)


async def similarity_search(
    query: str,
    *,
    doc_types: Optional[List[DocType]] = None,
    match_count: int = 8,
    match_threshold: float = 0.5,
) -> List[dict]:
    """
    Embeds the query and calls the `match_rag_documents` Postgres function
    (see supabase/migrations/0001_rag_setup.sql) which does the pgvector
    cosine-similarity search. Returns [{content, doc_type, source_id, metadata, similarity}, ...]
    """
    query_vector = await embed_query(query)

    result = supabase.rpc(
        "match_rag_documents",
        {
            "query_embedding": query_vector,
            "filter_doc_types": doc_types,  # NULL in SQL = no filter
            "match_threshold": match_threshold,
            "match_count": match_count,
        },
    ).execute()

    return result.data or []
