# ApexTalent — Recruiter AI Copilot (LLM + RAG + Action Engine)

Real implementation of the Copilot plan, replacing the 4-mode stub
(`recruiter_copilot_agent()` with hardcoded compare/rank/salary/questions
logic and no retrieval) with the full architecture from the product doc:
LLM reasoning, RAG retrieval, and an executable Action Engine.

## Architecture

```
Recruiter UI (/recruiter/copilot)
        │  POST /api/v1/recruiter/copilot/chat
        ▼
FastAPI endpoint (app/api/recruiter.py)
        │  loads conversation history from Supabase
        ▼
recruiter_copilot_agent()  (app/services/copilot/agent.py)
        │
        │  Claude tool-use loop (claude-sonnet-5)
        │
        ├──▶ rag_search ──▶ vector_store.similarity_search()
        │                      │
        │                      ▼
        │                 Supabase pgvector (rag_documents table)
        │                      ▲
        │                      │  embeddings via Voyage AI (voyage-3.5)
        │                 ingestion.py (resumes, GitHub analyses,
        │                 interview transcripts, notes, jobs, policies)
        │
        └──▶ Action Engine tools ──▶ actions.py
                   compare_candidates, rank_candidates, predict_salary,
                   generate_interview_questions/_summary,
                   get_todays_hiring_brief, get_pipeline_alerts,
                   explain_hiring_analytics, create_job/update_job,
                   shortlist/move_candidate, schedule_interview,
                   assign_assessment, create_coding_challenge,
                   draft/send_communication, create_automation_workflow,
                   generate_report
                        │
                        ▼
                 Supabase tables (candidates, jobs, applications,
                 interviews, communications_log, automation_workflows...)
```

Claude itself decides which tool(s) a message needs — there's no manual
intent-classification `if/elif` chain like the old stub. This is what makes
"Find Java developers who built payment systems" and "Compare Aarav vs
Vikram" and "Create a Backend Engineer job" all work through one endpoint.

## Files

```
backend/app/services/
  db.py                       - shared Supabase client

  rag/
    embeddings.py              - Voyage AI embedding client + text chunker
    vector_store.py            - pgvector upsert + cosine similarity search
    ingestion.py                - feeds resumes/GitHub analyses/interviews/
                                   notes/jobs/policies into the vector store

  copilot/
    llm.py                      - shared Claude client + one-shot generate_text()
    tools.py                    - every Copilot capability as a Claude tool schema
    actions.py                   - Action Engine: real implementation behind each tool
    agent.py                     - the tool-use loop (this IS the Copilot)

backend/app/api/recruiter.py    - FastAPI chat endpoint + conversation persistence

supabase/migrations/0001_rag_setup.sql
  - pgvector extension, rag_documents table, match_rag_documents() RPC,
    copilot_conversations / copilot_messages / copilot_action_log tables
```

## Setup

```bash
pip install anthropic supabase httpx fastapi
```

Env vars:
```
ANTHROPIC_API_KEY=sk-ant-...
VOYAGE_API_KEY=pa-...
SUPABASE_URL=https://xxxx.supabase.co
SUPABASE_SERVICE_ROLE_KEY=...
```

Run the migration:
```bash
supabase db push   # or paste 0001_rag_setup.sql into the Supabase SQL editor
```

Wire the router in your FastAPI app:
```python
from app.api.recruiter import router as recruiter_router
app.include_router(recruiter_router)
```

## Keeping RAG in sync

Call the ingestion functions whenever the underlying data is created or
changes — this is what makes retrieval accurate instead of stale:

```python
from app.services.rag.ingestion import ingest_resume, ingest_github_analysis, ingest_interview_transcript

# after resume parsing
await ingest_resume(candidate_id, resume_text, candidate_name)

# after your GitHub repo evaluator (ai-evaluation-engine) finishes
await ingest_github_analysis(candidate_id, evaluation.summary, repo_url, evaluation.overall_score)

# after an AI interview completes
await ingest_interview_transcript(candidate_id, interview_id, transcript, role)
```

## How the 12 plan sections map to this implementation

| Plan section | Implementation |
|---|---|
| 1. AI Chat Assistant | `agent.py` — universal entry point, all tools available |
| 2. Today's Hiring Brief | `get_todays_hiring_brief` tool + `GET /copilot/brief` |
| 3. AI Candidate Intelligence | `compare_candidates`, `rank_candidates`, + `rag_search` for profile summaries |
| 4. AI Talent Search (RAG) | `rag_search` over resumes/GitHub/interviews/notes |
| 5. Job Management Assistant | `create_job` (auto-generates description/skills/salary/screening Qs), `update_job` |
| 6. Interview Copilot | `generate_interview_questions`, `generate_interview_summary` |
| 7. Candidate Communication | `draft_communication`, `send_communication` |
| 8. Hiring Pipeline Intelligence | `get_pipeline_alerts` |
| 9. Hiring Analytics | `explain_hiring_analytics`, `generate_report` |
| 10. Recruitment Automation | `create_automation_workflow` (stores trigger + ordered actions; you'll need a small worker/cron to evaluate triggers and re-dispatch through `ACTION_DISPATCH`) |
| 11. Knowledge Assistant (RAG) | `rag_search` with `doc_types=["company_policy"]` — ingest via `ingest_company_policy()` |
| 12. Smart Notifications | Not built here — natural extension of `get_pipeline_alerts` + `get_todays_hiring_brief` pushed via a scheduled job to your existing notification channel |

## Notes

- **Schema assumption**: `actions.py` assumes `candidates`, `jobs`,
  `applications`, `interviews` tables already exist from your Talent Score /
  resume pipeline, with the obvious column names (`talent_score`,
  `authenticity_index`, etc.). Rename references if your columns differ —
  everything else (RAG, agent loop, tool schemas) is independent of that.
- **Automation workflows are stored, not yet auto-triggered.** `create_automation_workflow`
  persists the rule. To actually execute "if assessment > 85% → move to
  interview → notify HR → send email → schedule interview", add a small
  handler (Supabase trigger, or a cron job) that evaluates active workflows
  against events and calls the matching functions in `ACTION_DISPATCH`.
- **`send_communication` doesn't call a real email/WhatsApp provider yet** —
  it logs to `communications_log` so the action is auditable. Wire in Resend/
  SendGrid/Twilio where marked with `TODO`.
- Model choice: `AGENT_MODEL = "claude-sonnet-5"` in `llm.py` balances
  latency and reasoning quality for interactive chat. For cheaper high-volume
  use (e.g. auto-generating interview summaries for every completed
  interview), swap that specific call to `claude-haiku-4-5-20251001`.
