# backend/app/services/copilot/tools.py
#
# Every capability from the product plan (Chat Assistant, Hiring Brief,
# Candidate Intelligence, Talent Search/RAG, Job Management, Interview
# Copilot, Communication, Pipeline Intelligence, Analytics, Automation,
# Knowledge Assistant, Notifications) is exposed to Claude as a tool here.
# Claude decides which tool(s) a recruiter's natural-language message needs;
# agent.py runs the tool-use loop and actions.py holds the implementations.

COPILOT_TOOLS = [
    # --- RAG / retrieval -------------------------------------------------
    {
        "name": "rag_search",
        "description": (
            "Search across candidate resumes, GitHub analyses, interview transcripts, "
            "recruiter notes, job descriptions, and company policy docs using semantic "
            "search. Use this for open-ended natural-language questions like 'find Java "
            "developers who built payment systems' or 'what is our internship hiring policy' "
            "or 'summarize Rahul's profile' — anything that needs retrieval over stored data "
            "rather than a structured lookup."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Natural language search query"},
                "doc_types": {
                    "type": "array",
                    "items": {
                        "type": "string",
                        "enum": ["resume", "github_analysis", "interview_transcript", "recruiter_note",
                                 "job_description", "assessment_report", "company_policy", "email_template"],
                    },
                    "description": "Restrict search to these doc types. Omit to search everything.",
                },
            },
            "required": ["query"],
        },
    },
    # --- Candidate Intelligence -------------------------------------------
    {
        "name": "compare_candidates",
        "description": "Side-by-side comparison of two or more candidates across Talent Score, Coding Score, Authenticity Index, GitHub commit velocity, and tech-stack fit, with a hiring recommendation.",
        "input_schema": {
            "type": "object",
            "properties": {
                "candidate_ids": {"type": "array", "items": {"type": "string"}, "minItems": 2},
            },
            "required": ["candidate_ids"],
        },
    },
    {
        "name": "rank_candidates",
        "description": "Rank active applicants (optionally for a specific job) by verified Talent Score and return the top matches.",
        "input_schema": {
            "type": "object",
            "properties": {
                "job_id": {"type": "string", "description": "Optional job to scope the ranking to"},
                "top_n": {"type": "integer", "default": 10},
            },
        },
    },
    {
        "name": "predict_salary",
        "description": "Predict a fair competitive salary range for a candidate based on experience, verified Talent Score, and regional market data.",
        "input_schema": {
            "type": "object",
            "properties": {
                "candidate_id": {"type": "string"},
                "region": {"type": "string", "description": "e.g. 'Pune, India' or 'Remote - US'"},
            },
            "required": ["candidate_id"],
        },
    },
    # --- Interview Copilot -------------------------------------------------
    {
        "name": "generate_interview_questions",
        "description": "Generate role-specific technical/behavioral interview questions, optionally tailored to a specific candidate's gaps.",
        "input_schema": {
            "type": "object",
            "properties": {
                "role": {"type": "string"},
                "focus_areas": {"type": "array", "items": {"type": "string"}, "description": "e.g. ['system architecture', 'idempotency', 'circuit breaking']"},
                "candidate_id": {"type": "string", "description": "Optional — tailor to this candidate's known weak spots"},
            },
            "required": ["role"],
        },
    },
    {
        "name": "generate_interview_summary",
        "description": "After an interview, generate a structured summary: technical score, communication score, and hiring recommendation from the transcript.",
        "input_schema": {
            "type": "object",
            "properties": {"candidate_id": {"type": "string"}, "interview_id": {"type": "string"}},
            "required": ["candidate_id", "interview_id"],
        },
    },
    # --- Hiring Brief / Pipeline Intelligence / Analytics -------------------
    {
        "name": "get_todays_hiring_brief",
        "description": "Get today's hiring summary: active jobs, new applicants, interviews today, pending feedback, expiring offers, and AI-recommended next actions.",
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "get_pipeline_alerts",
        "description": "Get pipeline health alerts: candidates stuck >N days, delayed interviews, offers expiring soon, unscheduled interviews.",
        "input_schema": {"type": "object", "properties": {"stuck_threshold_days": {"type": "integer", "default": 7}}},
    },
    {
        "name": "explain_hiring_analytics",
        "description": "Answer analytical questions like 'why is hiring taking longer', 'which jobs are hardest to fill', 'best sourcing platform', 'average interview score' with explanation, not just numbers.",
        "input_schema": {
            "type": "object",
            "properties": {"question": {"type": "string"}, "job_id": {"type": "string"}},
            "required": ["question"],
        },
    },
    # --- Job Management ------------------------------------------------------
    {
        "name": "create_job",
        "description": "Create a new job posting. Generates description, responsibilities, required skills, salary range, and screening questions from a short prompt if not all fields are given.",
        "input_schema": {
            "type": "object",
            "properties": {
                "title": {"type": "string"},
                "seniority": {"type": "string"},
                "notes": {"type": "string", "description": "Free-text ask, e.g. 'Need Senior Full Stack Developer'"},
            },
            "required": ["title"],
        },
    },
    {
        "name": "update_job",
        "description": "Update fields on an existing job posting.",
        "input_schema": {
            "type": "object",
            "properties": {
                "job_id": {"type": "string"},
                "fields": {"type": "object", "description": "Fields to update, e.g. {status: 'closed'}"},
            },
            "required": ["job_id", "fields"],
        },
    },
    # --- Pipeline actions ------------------------------------------------------
    {
        "name": "shortlist_candidate",
        "description": "Move a candidate into the shortlist for a job.",
        "input_schema": {
            "type": "object",
            "properties": {"candidate_id": {"type": "string"}, "job_id": {"type": "string"}},
            "required": ["candidate_id", "job_id"],
        },
    },
    {
        "name": "move_candidate",
        "description": "Move a candidate to a different hiring pipeline stage.",
        "input_schema": {
            "type": "object",
            "properties": {
                "candidate_id": {"type": "string"},
                "job_id": {"type": "string"},
                "stage": {"type": "string", "enum": ["applied", "screening", "interview", "offer", "hired", "rejected"]},
            },
            "required": ["candidate_id", "job_id", "stage"],
        },
    },
    {
        "name": "schedule_interview",
        "description": "Schedule an interview for a candidate.",
        "input_schema": {
            "type": "object",
            "properties": {
                "candidate_id": {"type": "string"},
                "job_id": {"type": "string"},
                "interviewer_id": {"type": "string"},
                "scheduled_at": {"type": "string", "description": "ISO 8601 datetime"},
                "interview_type": {"type": "string", "enum": ["ai_screening", "technical", "behavioral", "final"]},
            },
            "required": ["candidate_id", "job_id", "scheduled_at", "interview_type"],
        },
    },
    {
        "name": "assign_assessment",
        "description": "Assign a coding/technical assessment to a candidate.",
        "input_schema": {
            "type": "object",
            "properties": {"candidate_id": {"type": "string"}, "assessment_template_id": {"type": "string"}},
            "required": ["candidate_id", "assessment_template_id"],
        },
    },
    {
        "name": "create_coding_challenge",
        "description": "Create a new coding challenge, optionally from a short spec (role + focus area).",
        "input_schema": {
            "type": "object",
            "properties": {"title": {"type": "string"}, "role": {"type": "string"}, "focus_area": {"type": "string"}, "difficulty": {"type": "string", "enum": ["easy", "medium", "hard"]}},
            "required": ["title", "role"],
        },
    },
    # --- Communication -----------------------------------------------------
    {
        "name": "draft_communication",
        "description": "Draft a candidate communication (interview invitation, rejection, offer letter, follow-up, salary negotiation, WhatsApp message) using candidate + job context.",
        "input_schema": {
            "type": "object",
            "properties": {
                "candidate_id": {"type": "string"},
                "job_id": {"type": "string"},
                "message_type": {"type": "string", "enum": ["interview_invitation", "rejection", "offer_letter", "follow_up", "salary_negotiation", "whatsapp"]},
                "tone": {"type": "string", "enum": ["formal", "warm", "concise"], "default": "warm"},
            },
            "required": ["candidate_id", "message_type"],
        },
    },
    {
        "name": "send_communication",
        "description": "Send a previously drafted (or newly generated) communication to a candidate via email or WhatsApp. Only call this after the recruiter has approved the draft.",
        "input_schema": {
            "type": "object",
            "properties": {
                "candidate_id": {"type": "string"},
                "channel": {"type": "string", "enum": ["email", "whatsapp"]},
                "subject": {"type": "string"},
                "body": {"type": "string"},
            },
            "required": ["candidate_id", "channel", "body"],
        },
    },
    # --- Automation ------------------------------------------------------
    {
        "name": "create_automation_workflow",
        "description": "Create an if-this-then-that hiring automation rule, e.g. 'if assessment score > 85, move to interview, notify HR, send email, schedule interview'.",
        "input_schema": {
            "type": "object",
            "properties": {
                "trigger": {"type": "object", "description": "e.g. {type: 'assessment_score', operator: '>', value: 85}"},
                "actions": {"type": "array", "items": {"type": "object"}, "description": "Ordered list of actions to run, each shaped like {action_name, params}"},
                "job_id": {"type": "string", "description": "Optional — scope the workflow to one job"},
            },
            "required": ["trigger", "actions"],
        },
    },
    {
        "name": "generate_report",
        "description": "Generate a hiring report (pipeline funnel, time-to-hire, sourcing effectiveness, diversity, interview scores).",
        "input_schema": {
            "type": "object",
            "properties": {
                "report_type": {"type": "string", "enum": ["pipeline_funnel", "time_to_hire", "sourcing_effectiveness", "interview_scores"]},
                "job_id": {"type": "string"},
                "date_range_days": {"type": "integer", "default": 30},
            },
            "required": ["report_type"],
        },
    },
]
