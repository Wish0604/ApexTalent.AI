# backend/app/services/rag/ingestion.py
#
# Call these whenever underlying data changes — after resume parsing, after a
# GitHub repo evaluation completes (see ai-evaluation-engine), after an AI
# interview finishes, after a recruiter adds a note, after a job is
# published. This keeps the vector store in sync so the Copilot's RAG search
# never answers from stale data.

from typing import Optional
from .vector_store import upsert_document


async def ingest_resume(candidate_id: str, resume_text: str, candidate_name: str, role_target: Optional[str] = None):
    await upsert_document(
        source_id=candidate_id,
        doc_type="resume",
        text=resume_text,
        metadata={"candidate_name": candidate_name, "role_target": role_target},
    )


async def ingest_github_analysis(candidate_id: str, evaluation_summary: str, repo_url: str, overall_score: float):
    await upsert_document(
        source_id=candidate_id,
        doc_type="github_analysis",
        text=evaluation_summary,
        metadata={"repo_url": repo_url, "overall_score": overall_score},
    )


async def ingest_interview_transcript(candidate_id: str, interview_id: str, transcript: str, role: str):
    await upsert_document(
        source_id=f"{candidate_id}:{interview_id}",
        doc_type="interview_transcript",
        text=transcript,
        metadata={"candidate_id": candidate_id, "interview_id": interview_id, "role": role},
    )


async def ingest_recruiter_note(candidate_id: str, note: str, recruiter_id: str):
    await upsert_document(
        source_id=f"{candidate_id}:note:{recruiter_id}",
        doc_type="recruiter_note",
        text=note,
        metadata={"candidate_id": candidate_id, "recruiter_id": recruiter_id},
    )


async def ingest_job_description(job_id: str, title: str, description: str, requirements: str):
    await upsert_document(
        source_id=job_id,
        doc_type="job_description",
        text=f"Title: {title}\n\n{description}\n\nRequirements:\n{requirements}",
        metadata={"title": title},
    )


async def ingest_company_policy(policy_id: str, title: str, text: str):
    await upsert_document(
        source_id=policy_id,
        doc_type="company_policy",
        text=f"{title}\n\n{text}",
        metadata={"title": title},
    )
