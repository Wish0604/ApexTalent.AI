-- supabase/migrations/0001_rag_setup.sql
-- Sets up pgvector + the single rag_documents table backing the Copilot's RAG engine.

create extension if not exists vector;

create table if not exists rag_documents (
  id bigint generated always as identity primary key,
  source_id text not null,        -- candidate_id / job_id / policy_id (+ suffix for multi-doc types)
  doc_type text not null,         -- resume | github_analysis | interview_transcript | recruiter_note
                                   -- | job_description | assessment_report | company_policy | email_template
  chunk_index int not null default 0,
  content text not null,
  embedding vector(1024) not null, -- voyage-3.5 dimension
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create index if not exists rag_documents_embedding_idx
  on rag_documents using ivfflat (embedding vector_cosine_ops)
  with (lists = 100);

create index if not exists rag_documents_doc_type_idx on rag_documents (doc_type);
create index if not exists rag_documents_source_id_idx on rag_documents (source_id);

-- Cosine-similarity search RPC used by vector_store.similarity_search()
create or replace function match_rag_documents(
  query_embedding vector(1024),
  filter_doc_types text[] default null,
  match_threshold float default 0.5,
  match_count int default 8
)
returns table (
  id bigint,
  source_id text,
  doc_type text,
  content text,
  metadata jsonb,
  similarity float
)
language sql stable
as $$
  select
    rag_documents.id,
    rag_documents.source_id,
    rag_documents.doc_type,
    rag_documents.content,
    rag_documents.metadata,
    1 - (rag_documents.embedding <=> query_embedding) as similarity
  from rag_documents
  where (filter_doc_types is null or rag_documents.doc_type = any(filter_doc_types))
    and 1 - (rag_documents.embedding <=> query_embedding) > match_threshold
  order by rag_documents.embedding <=> query_embedding
  limit match_count;
$$;

-- Minimal supporting tables referenced by the Action Engine (actions.py).
-- Adjust/extend to match your existing candidate & job schema if these
-- already exist elsewhere — these are here so the migration is self-contained.

create table if not exists copilot_action_log (
  id bigint generated always as identity primary key,
  recruiter_id text not null,
  action_name text not null,
  action_input jsonb not null,
  action_result jsonb,
  status text not null default 'success', -- success | failed
  created_at timestamptz not null default now()
);

create table if not exists copilot_conversations (
  id uuid primary key default gen_random_uuid(),
  recruiter_id text not null,
  created_at timestamptz not null default now()
);

create table if not exists copilot_messages (
  id bigint generated always as identity primary key,
  conversation_id uuid not null references copilot_conversations(id) on delete cascade,
  role text not null, -- user | assistant | tool
  content text not null,
  tool_calls jsonb,
  created_at timestamptz not null default now()
);
