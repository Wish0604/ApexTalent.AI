# backend/app/services/rag/embeddings.py
#
# Claude has no native embeddings endpoint, so the RAG engine uses Voyage AI
# (Anthropic's recommended embeddings partner) to turn text into vectors.
# Swap `EMBED_MODEL` / `embed_texts()` internals if you'd rather use a local
# sentence-transformers model — nothing else in the RAG pipeline needs to change.

import os
from typing import List
import httpx

VOYAGE_API_KEY = os.environ["VOYAGE_API_KEY"]
EMBED_MODEL = "voyage-3.5"  # 1024-dim, strong general + code retrieval performance
EMBED_DIM = 1024

VOYAGE_URL = "https://api.voyageai.com/v1/embeddings"


async def embed_texts(texts: List[str], input_type: str = "document") -> List[List[float]]:
    """
    input_type: "document" when embedding content to store (candidates, jobs,
    policies), "query" when embedding a recruiter's natural-language question.
    Voyage tunes the embedding differently for each — always set this correctly,
    mismatching it measurably hurts retrieval quality.
    """
    if not texts:
        return []

    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.post(
            VOYAGE_URL,
            headers={"Authorization": f"Bearer {VOYAGE_API_KEY}"},
            json={"model": EMBED_MODEL, "input": texts, "input_type": input_type},
        )
        resp.raise_for_status()
        data = resp.json()
        return [item["embedding"] for item in data["data"]]


async def embed_query(query: str) -> List[float]:
    vectors = await embed_texts([query], input_type="query")
    return vectors[0]


def chunk_text(text: str, max_chars: int = 1500, overlap: int = 150) -> List[str]:
    """Simple sliding-window chunker for long documents (resumes, policy docs, transcripts)."""
    if len(text) <= max_chars:
        return [text]
    chunks = []
    start = 0
    while start < len(text):
        end = min(start + max_chars, len(text))
        chunks.append(text[start:end])
        start += max_chars - overlap
    return chunks
