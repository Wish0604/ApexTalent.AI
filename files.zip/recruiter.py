# backend/app/api/recruiter.py
#
# POST /api/v1/recruiter/copilot/chat
# Replaces the old handler that called the 4-mode stub agent. Now routes
# every message through recruiter_copilot_agent(), which has full RAG +
# Action Engine access, and persists conversation turns to Supabase so the
# Copilot has memory across a session.

from typing import List, Optional
from uuid import UUID

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from app.services.copilot.agent import recruiter_copilot_agent
from app.services.db import supabase

router = APIRouter(prefix="/api/v1/recruiter", tags=["recruiter-copilot"])


class ChatRequest(BaseModel):
    message: str
    conversation_id: Optional[str] = None
    recruiter_id: str


class ChatResponse(BaseModel):
    conversation_id: str
    reply: str
    tool_calls: List[dict]
    actions_taken: List[str]


def _load_history(conversation_id: str) -> List[dict]:
    rows = (
        supabase.table("copilot_messages")
        .select("role, content")
        .eq("conversation_id", conversation_id)
        .order("created_at")
        .execute()
        .data
        or []
    )
    return [{"role": r["role"], "content": r["content"]} for r in rows]


def _get_or_create_conversation(conversation_id: Optional[str], recruiter_id: str) -> str:
    if conversation_id:
        return conversation_id
    inserted = supabase.table("copilot_conversations").insert({"recruiter_id": recruiter_id}).execute()
    return inserted.data[0]["id"]


def _save_message(conversation_id: str, role: str, content: str):
    supabase.table("copilot_messages").insert(
        {"conversation_id": conversation_id, "role": role, "content": content}
    ).execute()


@router.post("/copilot/chat", response_model=ChatResponse)
async def copilot_chat(req: ChatRequest):
    try:
        conversation_id = _get_or_create_conversation(req.conversation_id, req.recruiter_id)
        history = _load_history(conversation_id)

        result = await recruiter_copilot_agent(
            message=req.message,
            conversation_history=history,
            recruiter_id=req.recruiter_id,
        )

        _save_message(conversation_id, "user", req.message)
        _save_message(conversation_id, "assistant", result["reply"])

        return ChatResponse(
            conversation_id=conversation_id,
            reply=result["reply"],
            tool_calls=result["tool_calls"],
            actions_taken=result["actions_taken"],
        )
    except Exception as e:  # noqa: BLE001
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/copilot/brief")
async def hiring_brief():
    """Powers 'Today's Hiring Brief' shown on Copilot load, without going through chat."""
    from app.services.copilot.actions import get_todays_hiring_brief
    return await get_todays_hiring_brief()
