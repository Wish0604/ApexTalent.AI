# backend/app/services/copilot/agent.py
#
# This replaces the old recruiter_copilot_agent() stub. It runs a real Claude
# tool-use loop: Claude reads the recruiter's message + conversation history,
# decides which tool(s) it needs (RAG search and/or an Action Engine
# function), we execute them, feed results back, and let Claude produce the
# final markdown answer — repeating until Claude stops requesting tools.

import json
from typing import Any, Dict, List, Optional

from .llm import client, AGENT_MODEL
from .tools import COPILOT_TOOLS
from .actions import ACTION_DISPATCH
from ..rag.vector_store import similarity_search

SYSTEM_PROMPT = """You are the ApexTalent Recruiter AI Copilot — a conversational assistant \
embedded in the Recruiter Portal. You help recruiters search, analyze, recommend, automate, \
and execute recruitment tasks by calling the tools available to you.

Rules:
- Prefer calling a tool over guessing. If a question needs data (candidate metrics, pipeline \
state, policy text), use rag_search or the relevant structured tool — never invent numbers.
- For open-ended or fuzzy questions ("find Java developers who built payment systems", \
"what's our internship policy"), use rag_search.
- For actions that change data (create_job, schedule_interview, send_communication, \
move_candidate, create_automation_workflow), briefly confirm what you're about to do in your \
final answer so the recruiter can see what happened — you may execute directly, the UI shows \
the action as a chip the recruiter already reviewed before sending the message.
- Answer in clear markdown: short paragraphs, bullet points for lists, bold for key numbers \
and recommendations. Keep responses focused — recruiters are scanning between tasks.
- If a tool call fails or returns no data, say so plainly rather than fabricating a result.
"""


async def _execute_tool(name: str, tool_input: Dict[str, Any]) -> Any:
    if name == "rag_search":
        return await similarity_search(
            tool_input["query"],
            doc_types=tool_input.get("doc_types"),
        )
    handler = ACTION_DISPATCH.get(name)
    if handler is None:
        return {"error": f"Unknown tool '{name}'"}
    return await handler(**tool_input)


async def recruiter_copilot_agent(
    message: str,
    conversation_history: Optional[List[Dict[str, str]]] = None,
    recruiter_id: Optional[str] = None,
    max_tool_rounds: int = 5,
) -> Dict[str, Any]:
    """
    Main entry point called by the FastAPI endpoint. Returns:
      { "reply": "<markdown>", "tool_calls": [...], "actions_taken": [...] }
    """
    messages: List[Dict[str, Any]] = list(conversation_history or [])
    messages.append({"role": "user", "content": message})

    tool_call_log: List[Dict[str, Any]] = []
    actions_taken: List[str] = []

    for _ in range(max_tool_rounds):
        response = await client.messages.create(
            model=AGENT_MODEL,
            max_tokens=2000,
            system=SYSTEM_PROMPT,
            tools=COPILOT_TOOLS,
            messages=messages,
        )

        tool_use_blocks = [b for b in response.content if b.type == "tool_use"]

        if not tool_use_blocks:
            # Claude produced a final answer — no more tools needed
            text_block = next((b for b in response.content if b.type == "text"), None)
            return {
                "reply": text_block.text if text_block else "",
                "tool_calls": tool_call_log,
                "actions_taken": actions_taken,
            }

        # Claude wants to use one or more tools — execute them, then continue the loop
        messages.append({"role": "assistant", "content": response.content})

        tool_results = []
        for block in tool_use_blocks:
            tool_call_log.append({"name": block.name, "input": block.input})
            if block.name in ACTION_DISPATCH and block.name not in ("rag_search",):
                actions_taken.append(block.name)

            try:
                result = await _execute_tool(block.name, block.input)
            except Exception as e:  # noqa: BLE001 — surface tool failures to Claude, not a 500
                result = {"error": str(e)}

            tool_results.append(
                {
                    "type": "tool_result",
                    "tool_use_id": block.id,
                    "content": json.dumps(result, default=str)[:8000],  # guard against huge payloads
                }
            )

        messages.append({"role": "user", "content": tool_results})

    return {
        "reply": "I wasn't able to finish this request within the allowed number of tool calls — try narrowing the question.",
        "tool_calls": tool_call_log,
        "actions_taken": actions_taken,
    }
