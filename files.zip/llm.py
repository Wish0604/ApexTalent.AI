# backend/app/services/copilot/llm.py
#
# Thin shared wrapper so every part of the Copilot (agent loop + individual
# action handlers that need to *generate* text, like job descriptions or
# offer letters) uses one consistent Claude client and model choice.

import os
import anthropic

client = anthropic.AsyncAnthropic(api_key=os.environ["ANTHROPIC_API_KEY"])

# claude-sonnet-5 for the interactive agent loop (good latency/quality balance).
# Swap to claude-opus-4-8 for high-stakes generation (offer letters, final
# hiring recommendations) if you want the extra reasoning quality.
AGENT_MODEL = "claude-sonnet-5"
GENERATION_MODEL = "claude-sonnet-5"


async def generate_text(system: str, prompt: str, max_tokens: int = 1200) -> str:
    """One-shot generation for action handlers (job descriptions, email drafts, etc.)."""
    response = await client.messages.create(
        model=GENERATION_MODEL,
        max_tokens=max_tokens,
        system=system,
        messages=[{"role": "user", "content": prompt}],
    )
    text_block = next((b for b in response.content if b.type == "text"), None)
    return text_block.text if text_block else ""
