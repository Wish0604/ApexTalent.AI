# backend/app/services/copilot/actions.py
#
# The Action Engine. Every tool defined in tools.py has a real implementation
# here — either a Supabase read/write, or a Claude generation call, or both.
# agent.py dispatches tool_use blocks from Claude to these functions by name.
#
# Schema assumption: `candidates`, `jobs`, `applications`, `interviews` tables
# already exist (from your Talent Score / resume pipeline). Column names below
# are the obvious ones (candidates.talent_score, candidates.github_score, etc.)
# — rename to match your actual schema if it differs.

from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional

from ..db import supabase
from ..rag.vector_store import similarity_search
from .llm import generate_text


# ---------------------------------------------------------------------------
# Candidate Intelligence
# ---------------------------------------------------------------------------

async def compare_candidates(candidate_ids: List[str]) -> Dict[str, Any]:
    res = supabase.table("candidates").select(
        "id, full_name, talent_score, coding_score, authenticity_index, "
        "github_commit_velocity, tech_stack, experience_years"
    ).in_("id", candidate_ids).execute()
    candidates = res.data or []

    if len(candidates) < 2:
        return {"error": "Need at least 2 valid candidate_ids to compare."}

    comparison_table = "\n".join(
        f"- {c['full_name']}: Talent Score {c.get('talent_score')}, Coding Score {c.get('coding_score')}, "
        f"Authenticity Index {c.get('authenticity_index')}, GitHub commit velocity {c.get('github_commit_velocity')}, "
        f"Tech stack: {c.get('tech_stack')}, Experience: {c.get('experience_years')}y"
        for c in candidates
    )

    recommendation = await generate_text(
        system="You are a recruiting analyst. Compare candidates strictly on the metrics given. Be decisive and specific about trade-offs. 3-4 sentences max.",
        prompt=f"Candidates:\n{comparison_table}\n\nGive an executive hiring recommendation: who is the stronger candidate and why, citing the specific metrics.",
    )

    return {"candidates": candidates, "recommendation": recommendation}


async def rank_candidates(job_id: Optional[str] = None, top_n: int = 10) -> Dict[str, Any]:
    query = supabase.table("candidates").select(
        "id, full_name, talent_score, authenticity_index, fraud_flag"
    ).eq("fraud_flag", False).order("talent_score", desc=True).limit(top_n)

    if job_id:
        # Assumes an `applications` join table linking candidates to jobs
        app_ids = supabase.table("applications").select("candidate_id").eq("job_id", job_id).execute()
        candidate_ids = [a["candidate_id"] for a in (app_ids.data or [])]
        if not candidate_ids:
            return {"ranked": [], "note": "No applicants found for this job."}
        query = query.in_("id", candidate_ids)

    ranked = query.execute().data or []
    total = len(ranked)
    top_pct_cutoff = max(1, int(total * 0.03))
    for i, c in enumerate(ranked):
        c["rank"] = i + 1
        c["top_3_percent"] = i < top_pct_cutoff

    return {"ranked": ranked, "job_id": job_id}


async def predict_salary(candidate_id: str, region: Optional[str] = None) -> Dict[str, Any]:
    cand = supabase.table("candidates").select(
        "full_name, experience_years, talent_score, tech_stack"
    ).eq("id", candidate_id).single().execute().data

    if not cand:
        return {"error": f"Candidate {candidate_id} not found."}

    prediction = await generate_text(
        system=(
            "You are a compensation analyst. Predict a fair, competitive salary RANGE "
            "(not a single number) for the given candidate profile and region, plus a "
            "percentile position vs. typical market range. Give currency-appropriate figures "
            "(₹ for India regions, $ otherwise). Be concise — 3-4 sentences, end with the range on its own line."
        ),
        prompt=(
            f"Candidate: {cand['full_name']}\n"
            f"Experience: {cand.get('experience_years')} years\n"
            f"Verified Talent Score: {cand.get('talent_score')}/100\n"
            f"Tech stack: {cand.get('tech_stack')}\n"
            f"Region: {region or 'not specified — assume remote/global market'}"
        ),
    )
    return {"candidate": cand["full_name"], "prediction": prediction}


# ---------------------------------------------------------------------------
# Interview Copilot
# ---------------------------------------------------------------------------

async def generate_interview_questions(role: str, focus_areas: Optional[List[str]] = None, candidate_id: Optional[str] = None) -> Dict[str, Any]:
    weak_spots = ""
    if candidate_id:
        rag_hits = await similarity_search(f"weaknesses gaps for {role} candidate", doc_types=["interview_transcript", "recruiter_note"], match_count=3)
        if rag_hits:
            weak_spots = "\n\nKnown gaps from prior interviews/notes:\n" + "\n".join(f"- {h['content'][:200]}" for h in rag_hits)

    questions = await generate_text(
        system="You are a senior technical interviewer. Generate high-signal, role-specific interview questions — avoid generic textbook questions.",
        prompt=(
            f"Role: {role}\n"
            f"Focus areas: {', '.join(focus_areas) if focus_areas else 'system design, production trade-offs, testing strategy'}"
            f"{weak_spots}\n\n"
            "Generate 6 questions: mix of system architecture, one on idempotency, one on circuit breaking / resilience, "
            "and one on testing/mocking strategy (PyTest/Jest as relevant). Format as a numbered list, one line each."
        ),
    )
    return {"role": role, "questions": questions}


async def generate_interview_summary(candidate_id: str, interview_id: str) -> Dict[str, Any]:
    hits = await similarity_search(
        f"interview transcript {candidate_id} {interview_id}",
        doc_types=["interview_transcript"],
        match_count=5,
    )
    transcript = "\n".join(h["content"] for h in hits if h["metadata"].get("interview_id") == interview_id)
    if not transcript:
        return {"error": "No transcript found for that interview_id."}

    summary = await generate_text(
        system=(
            "You are grading a technical interview transcript. Return a structured summary with: "
            "Technical Score (0-100), Communication Score (0-100), Key Strengths, Key Gaps, and a "
            "Hiring Recommendation (Strong Hire / Hire / Lean Hire / No Hire / Strong No Hire) with a one-line reason."
        ),
        prompt=f"Transcript:\n{transcript}",
    )
    return {"candidate_id": candidate_id, "interview_id": interview_id, "summary": summary}


# ---------------------------------------------------------------------------
# Hiring Brief / Pipeline Intelligence / Analytics
# ---------------------------------------------------------------------------

async def get_todays_hiring_brief() -> Dict[str, Any]:
    today = datetime.utcnow().date().isoformat()

    active_jobs = supabase.table("jobs").select("id", count="exact").eq("status", "active").execute().count or 0
    new_applicants = supabase.table("applications").select("id", count="exact").gte("created_at", today).execute().count or 0
    interviews_today = supabase.table("interviews").select("id", count="exact").gte("scheduled_at", today).lt(
        "scheduled_at", (datetime.utcnow().date() + timedelta(days=1)).isoformat()
    ).execute().count or 0
    pending_feedback = supabase.table("interviews").select("id", count="exact").eq("status", "completed").is_("feedback", "null").execute().count or 0
    expiring_offers = supabase.table("applications").select("id", count="exact").eq("stage", "offer").lte(
        "offer_expires_at", (datetime.utcnow() + timedelta(days=2)).isoformat()
    ).execute().count or 0

    recommendations = []
    if pending_feedback > 0:
        recommendations.append(f"Review feedback for {pending_feedback} completed interview(s)")
    if interviews_today > 0:
        recommendations.append(f"{interviews_today} interview(s) scheduled today — confirm interviewer availability")
    if expiring_offers > 0:
        recommendations.append(f"{expiring_offers} offer(s) expiring within 48 hours — follow up")

    return {
        "active_jobs": active_jobs,
        "new_applicants": new_applicants,
        "interviews_today": interviews_today,
        "pending_feedback": pending_feedback,
        "expiring_offers": expiring_offers,
        "recommendations": recommendations,
    }


async def get_pipeline_alerts(stuck_threshold_days: int = 7) -> Dict[str, Any]:
    cutoff = (datetime.utcnow() - timedelta(days=stuck_threshold_days)).isoformat()

    stuck = supabase.table("applications").select("id, candidate_id, job_id, stage, updated_at").lt(
        "updated_at", cutoff
    ).not_.in_("stage", ["hired", "rejected"]).execute().data or []

    unscheduled = supabase.table("applications").select("id, candidate_id, job_id").eq(
        "stage", "interview"
    ).is_("interview_id", "null").execute().data or []

    expiring = supabase.table("applications").select("id, candidate_id, offer_expires_at").eq(
        "stage", "offer"
    ).lte("offer_expires_at", (datetime.utcnow() + timedelta(days=1)).isoformat()).execute().data or []

    return {
        "stuck_candidates": stuck,
        "stuck_count": len(stuck),
        "unscheduled_interviews": unscheduled,
        "offers_expiring_tomorrow": expiring,
    }


async def explain_hiring_analytics(question: str, job_id: Optional[str] = None) -> Dict[str, Any]:
    # Pull the raw numbers analytics needs, then let Claude explain them in context
    q = supabase.table("applications").select("id, stage, created_at, updated_at, source, job_id")
    if job_id:
        q = q.eq("job_id", job_id)
    applications = q.execute().data or []

    stage_counts: Dict[str, int] = {}
    source_counts: Dict[str, int] = {}
    for a in applications:
        stage_counts[a["stage"]] = stage_counts.get(a["stage"], 0) + 1
        source_counts[a.get("source", "unknown")] = source_counts.get(a.get("source", "unknown"), 0) + 1

    explanation = await generate_text(
        system="You are a recruiting analytics assistant. Explain the 'why' behind hiring metrics in plain language, not just restate numbers. Be specific and actionable.",
        prompt=(
            f"Recruiter question: {question}\n\n"
            f"Pipeline stage counts: {stage_counts}\n"
            f"Applications by source: {source_counts}\n"
            f"Total applications in scope: {len(applications)}"
        ),
    )
    return {"question": question, "stage_counts": stage_counts, "source_counts": source_counts, "explanation": explanation}


# ---------------------------------------------------------------------------
# Job Management
# ---------------------------------------------------------------------------

async def create_job(title: str, seniority: Optional[str] = None, notes: Optional[str] = None) -> Dict[str, Any]:
    generated = await generate_text(
        system=(
            "You are a technical recruiter writing a job posting. Return sections clearly labeled: "
            "Description, Responsibilities, Required Skills, Suggested Salary Range, Screening Questions (3-5)."
        ),
        prompt=f"Job title: {title}\nSeniority: {seniority or 'not specified'}\nRecruiter notes: {notes or 'none'}",
    )

    row = {
        "title": title,
        "seniority": seniority,
        "generated_content": generated,
        "status": "draft",
        "created_at": datetime.utcnow().isoformat(),
    }
    inserted = supabase.table("jobs").insert(row).execute()
    job = (inserted.data or [row])[0]

    # Immediately index the new job description for RAG so talent search can find it
    from ..rag.ingestion import ingest_job_description
    await ingest_job_description(job.get("id", title), title, generated, notes or "")

    return {"job": job, "generated_content": generated}


async def update_job(job_id: str, fields: Dict[str, Any]) -> Dict[str, Any]:
    updated = supabase.table("jobs").update(fields).eq("id", job_id).execute()
    return {"job_id": job_id, "updated_fields": fields, "result": updated.data}


# ---------------------------------------------------------------------------
# Pipeline actions
# ---------------------------------------------------------------------------

async def shortlist_candidate(candidate_id: str, job_id: str) -> Dict[str, Any]:
    result = supabase.table("applications").update({"stage": "screening", "shortlisted": True}).eq(
        "candidate_id", candidate_id
    ).eq("job_id", job_id).execute()
    return {"candidate_id": candidate_id, "job_id": job_id, "status": "shortlisted", "result": result.data}


async def move_candidate(candidate_id: str, job_id: str, stage: str) -> Dict[str, Any]:
    result = supabase.table("applications").update({"stage": stage, "updated_at": datetime.utcnow().isoformat()}).eq(
        "candidate_id", candidate_id
    ).eq("job_id", job_id).execute()
    return {"candidate_id": candidate_id, "job_id": job_id, "new_stage": stage, "result": result.data}


async def schedule_interview(candidate_id: str, job_id: str, scheduled_at: str, interview_type: str, interviewer_id: Optional[str] = None) -> Dict[str, Any]:
    row = {
        "candidate_id": candidate_id,
        "job_id": job_id,
        "interviewer_id": interviewer_id,
        "scheduled_at": scheduled_at,
        "interview_type": interview_type,
        "status": "scheduled",
    }
    inserted = supabase.table("interviews").insert(row).execute()
    await move_candidate(candidate_id, job_id, "interview")
    return {"interview": (inserted.data or [row])[0]}


async def assign_assessment(candidate_id: str, assessment_template_id: str) -> Dict[str, Any]:
    row = {
        "candidate_id": candidate_id,
        "assessment_template_id": assessment_template_id,
        "assigned_at": datetime.utcnow().isoformat(),
        "status": "assigned",
    }
    inserted = supabase.table("assessment_assignments").insert(row).execute()
    return {"assignment": (inserted.data or [row])[0]}


async def create_coding_challenge(title: str, role: str, focus_area: Optional[str] = None, difficulty: str = "medium") -> Dict[str, Any]:
    spec = await generate_text(
        system="You are a technical assessment designer. Write a coding challenge: problem statement, input/output spec, constraints, and 3 test cases (no solutions).",
        prompt=f"Title: {title}\nRole: {role}\nFocus area: {focus_area or 'general problem solving'}\nDifficulty: {difficulty}",
    )
    row = {"title": title, "role": role, "difficulty": difficulty, "spec": spec, "created_at": datetime.utcnow().isoformat()}
    inserted = supabase.table("coding_challenges").insert(row).execute()
    return {"challenge": (inserted.data or [row])[0]}


# ---------------------------------------------------------------------------
# Communication
# ---------------------------------------------------------------------------

MESSAGE_TYPE_INSTRUCTIONS = {
    "interview_invitation": "Invite the candidate to interview. Include a placeholder for date/time and next steps.",
    "rejection": "Politely decline the candidate. Be respectful and specific about fit without being discouraging. Keep it short.",
    "offer_letter": "Draft an offer letter: role, key terms placeholder, and next steps to accept.",
    "follow_up": "Friendly check-in on where the candidate stands in the process.",
    "salary_negotiation": "Respond to a candidate's compensation ask — professional, leaves room for negotiation.",
    "whatsapp": "Very short, casual WhatsApp-style message — a few lines max.",
}


async def draft_communication(candidate_id: str, message_type: str, job_id: Optional[str] = None, tone: str = "warm") -> Dict[str, Any]:
    cand = supabase.table("candidates").select("full_name").eq("id", candidate_id).single().execute().data or {}
    job = supabase.table("jobs").select("title").eq("id", job_id).single().execute().data if job_id else {}

    draft = await generate_text(
        system=f"You draft recruiting communications. Tone: {tone}. {MESSAGE_TYPE_INSTRUCTIONS.get(message_type, '')}",
        prompt=f"Candidate: {cand.get('full_name', 'the candidate')}\nRole: {job.get('title', 'the role') if job else 'the role'}",
    )
    return {"candidate_id": candidate_id, "message_type": message_type, "draft": draft}


async def send_communication(candidate_id: str, channel: str, body: str, subject: Optional[str] = None) -> Dict[str, Any]:
    # TODO: wire to your actual email/WhatsApp provider (e.g. Resend, Twilio).
    # Logged here so the action is auditable regardless of provider wiring status.
    row = {
        "candidate_id": candidate_id,
        "channel": channel,
        "subject": subject,
        "body": body,
        "sent_at": datetime.utcnow().isoformat(),
    }
    supabase.table("communications_log").insert(row).execute()
    return {"status": "queued", "candidate_id": candidate_id, "channel": channel}


# ---------------------------------------------------------------------------
# Automation & Reporting
# ---------------------------------------------------------------------------

async def create_automation_workflow(trigger: Dict[str, Any], actions: List[Dict[str, Any]], job_id: Optional[str] = None) -> Dict[str, Any]:
    row = {
        "trigger": trigger,
        "actions": actions,
        "job_id": job_id,
        "active": True,
        "created_at": datetime.utcnow().isoformat(),
    }
    inserted = supabase.table("automation_workflows").insert(row).execute()
    return {"workflow": (inserted.data or [row])[0]}


async def generate_report(report_type: str, job_id: Optional[str] = None, date_range_days: int = 30) -> Dict[str, Any]:
    since = (datetime.utcnow() - timedelta(days=date_range_days)).isoformat()
    q = supabase.table("applications").select("*").gte("created_at", since)
    if job_id:
        q = q.eq("job_id", job_id)
    applications = q.execute().data or []

    narrative = await generate_text(
        system="You write concise hiring reports for recruiters. Lead with the headline number, then 2-3 supporting observations.",
        prompt=f"Report type: {report_type}\nDate range: last {date_range_days} days\nRecord count: {len(applications)}\nRaw records: {applications[:50]}",
    )
    return {"report_type": report_type, "record_count": len(applications), "narrative": narrative}


# ---------------------------------------------------------------------------
# Dispatch table — used by agent.py's tool-use loop
# ---------------------------------------------------------------------------

ACTION_DISPATCH = {
    "compare_candidates": compare_candidates,
    "rank_candidates": rank_candidates,
    "predict_salary": predict_salary,
    "generate_interview_questions": generate_interview_questions,
    "generate_interview_summary": generate_interview_summary,
    "get_todays_hiring_brief": get_todays_hiring_brief,
    "get_pipeline_alerts": get_pipeline_alerts,
    "explain_hiring_analytics": explain_hiring_analytics,
    "create_job": create_job,
    "update_job": update_job,
    "shortlist_candidate": shortlist_candidate,
    "move_candidate": move_candidate,
    "schedule_interview": schedule_interview,
    "assign_assessment": assign_assessment,
    "create_coding_challenge": create_coding_challenge,
    "draft_communication": draft_communication,
    "send_communication": send_communication,
    "create_automation_workflow": create_automation_workflow,
    "generate_report": generate_report,
}
